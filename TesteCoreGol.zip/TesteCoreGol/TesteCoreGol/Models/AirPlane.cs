﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace TesteCoreGol.Models
{
    [Table("tblAirPlane")]
    public class AirPlane
    {
        [Key]
        [Display(Name = "Código Avião")]
        public int CodAviao { get; set; }

        [Display(Name = "Modelo")]
        public string Modelo { get; set; }

        [Display(Name = "Quantidade de Passageiros")]
        public int QtdPassageiros { get; set; }

        [Display(Name = "Data Registro")]
        public DateTime DtCriacaoReg { get; set; }
    }
}
