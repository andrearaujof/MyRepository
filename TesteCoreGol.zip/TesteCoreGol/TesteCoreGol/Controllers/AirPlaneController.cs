﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using TesteCoreGol.Context;
using TesteCoreGol.Models;

namespace TesteCoreGol.Controllers
{
    public class AirPlaneController : Controller
    {
        private readonly AppDbContext _context;

        public AirPlaneController(AppDbContext context)
        {
            _context = context;
        }

        // GET: AirPlane
        public async Task<IActionResult> Index()
        {
            return View(await _context.AirPlane.ToListAsync());
        }

        // GET: AirPlane/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var airPlane = await _context.AirPlane
                .FirstOrDefaultAsync(m => m.CodAviao == id);
            if (airPlane == null)
            {
                return NotFound();
            }

            return View(airPlane);
        }

        // GET: AirPlane/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: AirPlane/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("CodAviao,Modelo,QtdPassageiros,DtCriacaoReg")] AirPlane airPlane)
        {
            if (ModelState.IsValid)
            {
                _context.Add(airPlane);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(airPlane);
        }

        // GET: AirPlane/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var airPlane = await _context.AirPlane.FindAsync(id);
            if (airPlane == null)
            {
                return NotFound();
            }
            return View(airPlane);
        }

        // POST: AirPlane/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("CodAviao,Modelo,QtdPassageiros,DtCriacaoReg")] AirPlane airPlane)
        {
            if (id != airPlane.CodAviao)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(airPlane);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!AirPlaneExists(airPlane.CodAviao))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(airPlane);
        }

        // GET: AirPlane/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var airPlane = await _context.AirPlane
                .FirstOrDefaultAsync(m => m.CodAviao == id);
            if (airPlane == null)
            {
                return NotFound();
            }

            return View(airPlane);
        }

        // POST: AirPlane/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var airPlane = await _context.AirPlane.FindAsync(id);
            _context.AirPlane.Remove(airPlane);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool AirPlaneExists(int id)
        {
            return _context.AirPlane.Any(e => e.CodAviao == id);
        }
    }
}
