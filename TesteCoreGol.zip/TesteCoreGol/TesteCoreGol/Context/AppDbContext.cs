﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TesteCoreGol.Models;

namespace TesteCoreGol.Context
{
    public class AppDbContext : DbContext
    {
        public virtual DbSet<AirPlane> AirPlane { get; set; }
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }
    }
}
